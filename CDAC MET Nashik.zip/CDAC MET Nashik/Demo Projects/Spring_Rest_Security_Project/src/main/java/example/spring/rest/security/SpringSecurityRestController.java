package example.spring.rest.security;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringSecurityRestController {
	@GetMapping("/doGreet")//This resource does not need security
	public String getGreeting() {
		return "Welcome to Spring Security";
	}
	
	//This resource is accessible only to ADMIN users
	@GetMapping("/doAdminWork")
	public String doAdminWork() {
		return "Doing admin work";
	}
	
	//This resource is accessible to ADMIN as well as REGULAR users
	@GetMapping("/doRegularWork")
	public String doRegularWork() {
		return "Doing regular work";
	}
}
