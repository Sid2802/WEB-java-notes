package example.spring.core.without_xml;

public class TestImpl {

	public TestImpl() {
		System.out.println("Inside TestImpl()");
	}

}
