package example.spring.core.without_xml;

public class GreetingImpl {
	public void doGreet() {
		System.out.println("Hello all, good morning !!");
	}
}
