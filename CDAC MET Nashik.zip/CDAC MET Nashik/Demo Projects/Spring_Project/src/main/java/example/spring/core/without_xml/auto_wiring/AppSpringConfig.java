package example.spring.core.without_xml.auto_wiring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class AppSpringConfig {
	//Configuration of 3 beans: Engine, MusicSystem and Car
	@Bean("carEngine")
	
	public Engine getEngine() {
		Engine eng = new Engine("1600 CC", "Petrol");//Constructor Injection
		return eng;
	}
	@Bean("carSuperEngine")
	//@Primary
	public Engine getSuperEngine() {
		Engine eng = new Engine("2000 CC", "Petrol");//Constructor Injection
		return eng;
	}
	@Bean("carMusicSystem")
	public MusicSystem getMusicSystem() {
		MusicSystem ms = new MusicSystem();//Setter Injection
		ms.setMake("Sony");
		ms.setSoundEffect("Dolby");
		return ms;
	}
	
	@Bean("myCar")
	public Car getMyCar() {
		Car myCar = new Car();
		myCar.setMake("Hyundai");
		myCar.setModel("Creta");
		myCar.setPrice(1650000);
		return myCar;
		/*Did not set values for engineDetails and musicSystemDetails
		 * properties because they will get auto wired.
		 */
		
	}
}





