package example.spring.core.without_xml;

public class MessageImpl {
	public void printMessage(String message, String name) {
		System.out.println(message + " " + name);
	}
}
