package third;

import org.springframework.stereotype.Component;

@Component
public class ThirdTestComponent {
	public void doTest() {
		System.out.println("ThirdTestComponent test succeeded.");
	}
}
